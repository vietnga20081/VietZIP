#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
VietZIP 📦 — Ứng dụng nén / giải nén ZIP với giao diện hiện đại, ngộ nghĩnh.

Công nghệ:
    - Python 3.9+
    - CustomTkinter (giao diện hiện đại, bo góc, dark/light mode)
    - zipfile / shutil (thư viện chuẩn) để nén & giải nén
    - threading để xử lý nền, không đơ giao diện

Chạy:
    pip install -r requirements.txt
    python vietzip_app.py
"""

import os
import sys
import time
import queue
import shutil
import zipfile
import threading
import traceback
from pathlib import Path
from datetime import datetime
from tkinter import filedialog, messagebox

import customtkinter as ctk

# ────────────────────────────────────────────────────────────────────────────
#  CẤU HÌNH GIAO DIỆN
# ────────────────────────────────────────────────────────────────────────────
ctk.set_appearance_mode("System")
ctk.set_default_color_theme("green")

APP_NAME = "VietZIP"
APP_EMOJI = "📦"
FONT_TITLE = ("Segoe UI Emoji", 26, "bold")
FONT_SUB = ("Segoe UI", 13)
FONT_NORMAL = ("Segoe UI", 13)
FONT_MONO = ("Consolas", 11)

MASCOT_IDLE = ["📦", "🐼", "🧧", "🎋"]
MASCOT_WORKING = ["⚙️", "🌀", "✨", "🚀"]
MASCOT_DONE = ["🎉", "✅", "🥳", "🏆"]

COMPRESSION_LEVELS = {
    "Siêu nhanh (không nén)": 0,
    "Nhanh": 3,
    "Cân bằng ⭐": 6,
    "Nén tối đa 🐢": 9,
}


def human_size(num_bytes: float) -> str:
    """Đổi số byte thành chuỗi dễ đọc: 1.2 MB, 340 KB, ..."""
    for unit in ["B", "KB", "MB", "GB", "TB"]:
        if abs(num_bytes) < 1024.0:
            return f"{num_bytes:3.1f} {unit}"
        num_bytes /= 1024.0
    return f"{num_bytes:.1f} PB"


def iter_files_for_compression(paths):
    """
    Sinh ra danh sách (đường_dẫn_thật, tên_trong_zip) cho mọi file/thư mục
    được chọn, giữ nguyên cấu trúc thư mục con.
    """
    for p in paths:
        p = Path(p)
        if p.is_file():
            yield p, p.name
        elif p.is_dir():
            base_parent = p.parent
            for root, _, files in os.walk(p):
                for f in files:
                    full = Path(root) / f
                    arcname = full.relative_to(base_parent)
                    yield full, arcname


# ────────────────────────────────────────────────────────────────────────────
#  LỚP XỬ LÝ NÉN / GIẢI NÉN (chạy trong luồng nền)
# ────────────────────────────────────────────────────────────────────────────
class ZipWorker(threading.Thread):
    """Luồng nền thực hiện nén hoặc giải nén, báo tiến độ qua queue."""

    def __init__(self, mode, payload, msg_queue: queue.Queue):
        super().__init__(daemon=True)
        self.mode = mode          # "compress" | "extract"
        self.payload = payload    # dict chứa thông tin cần thiết
        self.msg_queue = msg_queue

    def run(self):
        try:
            if self.mode == "compress":
                self._compress()
            else:
                self._extract()
        except Exception as exc:  # noqa: BLE001
            traceback.print_exc()
            self.msg_queue.put(("error", str(exc)))

    # ---- Nén ----
    def _compress(self):
        sources = self.payload["sources"]
        output_path = self.payload["output_path"]
        level = self.payload["level"]

        entries = list(iter_files_for_compression(sources))
        total = max(len(entries), 1)
        original_size = 0

        with zipfile.ZipFile(
            output_path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=level
        ) as zf:
            for i, (full_path, arcname) in enumerate(entries, start=1):
                try:
                    original_size += full_path.stat().st_size
                except OSError:
                    pass
                zf.write(full_path, arcname=str(arcname))
                self.msg_queue.put(
                    ("progress", i / total, f"Đang nén: {arcname}")
                )

        compressed_size = os.path.getsize(output_path)
        self.msg_queue.put(
            (
                "compress_done",
                {
                    "output_path": output_path,
                    "file_count": total,
                    "original_size": original_size,
                    "compressed_size": compressed_size,
                },
            )
        )

    # ---- Giải nén ----
    def _extract(self):
        zip_path = self.payload["zip_path"]
        dest_dir = self.payload["dest_dir"]

        with zipfile.ZipFile(zip_path, "r") as zf:
            members = zf.infolist()
            total = max(len(members), 1)
            for i, member in enumerate(members, start=1):
                zf.extract(member, path=dest_dir)
                self.msg_queue.put(
                    ("progress", i / total, f"Đang giải nén: {member.filename}")
                )

        self.msg_queue.put(
            ("extract_done", {"dest_dir": dest_dir, "file_count": total})
        )


# ────────────────────────────────────────────────────────────────────────────
#  GIAO DIỆN CHÍNH
# ────────────────────────────────────────────────────────────────────────────
class VietZipApp(ctk.CTk):
    def __init__(self):
        super().__init__()

        self.title(f"{APP_NAME} {APP_EMOJI} — Nén & Giải nén thần tốc")
        self.geometry("880x620")
        self.minsize(760, 560)

        self.msg_queue: queue.Queue = queue.Queue()
        self.compress_items: list[str] = []
        self.worker: ZipWorker | None = None

        self._build_layout()
        self.after(120, self._poll_queue)

    # ------------------------------------------------------------------ UI --
    def _build_layout(self):
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(1, weight=1)

        # ---- Header ----
        header = ctk.CTkFrame(self, corner_radius=0, fg_color=("gray90", "gray14"))
        header.grid(row=0, column=0, sticky="ew")
        header.grid_columnconfigure(1, weight=1)

        self.mascot_label = ctk.CTkLabel(
            header, text=MASCOT_IDLE[0], font=("Segoe UI Emoji", 40)
        )
        self.mascot_label.grid(row=0, column=0, padx=(20, 10), pady=14)

        title_box = ctk.CTkFrame(header, fg_color="transparent")
        title_box.grid(row=0, column=1, sticky="w", pady=14)
        ctk.CTkLabel(title_box, text=f"{APP_NAME}", font=FONT_TITLE).pack(anchor="w")
        ctk.CTkLabel(
            title_box,
            text="Nén và giải nén ZIP siêu tốc, siêu dễ thương ✨",
            font=FONT_SUB,
            text_color=("gray30", "gray70"),
        ).pack(anchor="w")

        self.appearance_switch = ctk.CTkSegmentedButton(
            header,
            values=["☀️ Sáng", "🌙 Tối", "🖥️ Hệ thống"],
            command=self._on_appearance_change,
        )
        self.appearance_switch.set("🖥️ Hệ thống")
        self.appearance_switch.grid(row=0, column=2, padx=20)

        # ---- Tabs ----
        self.tabview = ctk.CTkTabview(self, corner_radius=16)
        self.tabview.grid(row=1, column=0, sticky="nsew", padx=20, pady=(14, 8))
        self.tab_compress = self.tabview.add("🗜️  Nén file")
        self.tab_extract = self.tabview.add("📂  Giải nén")

        self._build_compress_tab(self.tab_compress)
        self._build_extract_tab(self.tab_extract)

        # ---- Status bar / progress ----
        status_frame = ctk.CTkFrame(self, corner_radius=12)
        status_frame.grid(row=2, column=0, sticky="ew", padx=20, pady=(0, 16))
        status_frame.grid_columnconfigure(0, weight=1)

        self.progress_bar = ctk.CTkProgressBar(status_frame)
        self.progress_bar.set(0)
        self.progress_bar.grid(row=0, column=0, sticky="ew", padx=16, pady=(14, 4))

        self.status_label = ctk.CTkLabel(
            status_frame,
            text="Sẵn sàng! Hãy chọn file để bắt đầu nhé 😺",
            font=FONT_NORMAL,
            anchor="w",
        )
        self.status_label.grid(row=1, column=0, sticky="ew", padx=16, pady=(0, 14))

    # ---- Tab: Nén ----
    def _build_compress_tab(self, tab):
        tab.grid_columnconfigure(0, weight=1)
        tab.grid_rowconfigure(1, weight=1)

        btn_row = ctk.CTkFrame(tab, fg_color="transparent")
        btn_row.grid(row=0, column=0, sticky="ew", pady=(10, 6))

        ctk.CTkButton(
            btn_row, text="➕ Thêm file", command=self._add_files
        ).pack(side="left", padx=(0, 8))
        ctk.CTkButton(
            btn_row, text="📁 Thêm thư mục", command=self._add_folder
        ).pack(side="left", padx=8)
        ctk.CTkButton(
            btn_row,
            text="🗑️ Xóa hết",
            fg_color="transparent",
            border_width=1,
            command=self._clear_compress_list,
        ).pack(side="left", padx=8)

        self.file_list_box = ctk.CTkScrollableFrame(
            tab, label_text="📋 Danh sách sẽ được nén"
        )
        self.file_list_box.grid(row=1, column=0, sticky="nsew", pady=6)
        self._empty_hint = ctk.CTkLabel(
            self.file_list_box,
            text="Chưa có gì ở đây cả... hãy thêm file hoặc thư mục! 🌱",
            text_color=("gray40", "gray60"),
        )
        self._empty_hint.pack(pady=30)

        options_row = ctk.CTkFrame(tab, fg_color="transparent")
        options_row.grid(row=2, column=0, sticky="ew", pady=8)

        ctk.CTkLabel(options_row, text="Mức độ nén:", font=FONT_NORMAL).pack(
            side="left", padx=(0, 8)
        )
        self.level_menu = ctk.CTkOptionMenu(
            options_row, values=list(COMPRESSION_LEVELS.keys())
        )
        self.level_menu.set("Cân bằng ⭐")
        self.level_menu.pack(side="left")

        self.compress_button = ctk.CTkButton(
            tab,
            text="🚀 Nén ngay!",
            height=44,
            font=("Segoe UI", 15, "bold"),
            command=self._start_compress,
        )
        self.compress_button.grid(row=3, column=0, sticky="ew", pady=(4, 10))

    # ---- Tab: Giải nén ----
    def _build_extract_tab(self, tab):
        tab.grid_columnconfigure(0, weight=1)

        self.zip_path_var = ctk.StringVar(value="")
        self.dest_dir_var = ctk.StringVar(value="")

        pick_zip_row = ctk.CTkFrame(tab, fg_color="transparent")
        pick_zip_row.grid(row=0, column=0, sticky="ew", pady=(20, 10))
        pick_zip_row.grid_columnconfigure(0, weight=1)

        ctk.CTkEntry(
            pick_zip_row,
            textvariable=self.zip_path_var,
            placeholder_text="Chưa chọn file .zip nào...",
        ).grid(row=0, column=0, sticky="ew", padx=(0, 8))
        ctk.CTkButton(
            pick_zip_row, text="📦 Chọn ZIP", width=130, command=self._choose_zip
        ).grid(row=0, column=1)

        pick_dest_row = ctk.CTkFrame(tab, fg_color="transparent")
        pick_dest_row.grid(row=1, column=0, sticky="ew", pady=10)
        pick_dest_row.grid_columnconfigure(0, weight=1)

        ctk.CTkEntry(
            pick_dest_row,
            textvariable=self.dest_dir_var,
            placeholder_text="Chưa chọn nơi giải nén...",
        ).grid(row=0, column=0, sticky="ew", padx=(0, 8))
        ctk.CTkButton(
            pick_dest_row, text="📂 Chọn thư mục", width=130, command=self._choose_dest
        ).grid(row=0, column=1)

        self.zip_contents_box = ctk.CTkTextbox(tab, font=FONT_MONO)
        self.zip_contents_box.grid(row=2, column=0, sticky="nsew", pady=10)
        self.zip_contents_box.configure(state="disabled")
        tab.grid_rowconfigure(2, weight=1)

        self.extract_button = ctk.CTkButton(
            tab,
            text="✨ Giải nén ngay!",
            height=44,
            font=("Segoe UI", 15, "bold"),
            command=self._start_extract,
        )
        self.extract_button.grid(row=3, column=0, sticky="ew", pady=(4, 14))

    # ------------------------------------------------------------ Actions --
    def _on_appearance_change(self, value):
        mapping = {"☀️ Sáng": "Light", "🌙 Tối": "Dark", "🖥️ Hệ thống": "System"}
        ctk.set_appearance_mode(mapping.get(value, "System"))

    def _set_mascot(self, pool, index=0):
        self.mascot_label.configure(text=pool[index % len(pool)])

    # ---- Nén: quản lý danh sách file ----
    def _refresh_file_list_ui(self):
        for child in self.file_list_box.winfo_children():
            child.destroy()

        if not self.compress_items:
            self._empty_hint = ctk.CTkLabel(
                self.file_list_box,
                text="Chưa có gì ở đây cả... hãy thêm file hoặc thư mục! 🌱",
                text_color=("gray40", "gray60"),
            )
            self._empty_hint.pack(pady=30)
            return

        for path_str in self.compress_items:
            row = ctk.CTkFrame(self.file_list_box)
            row.pack(fill="x", pady=3, padx=2)
            icon = "📁" if os.path.isdir(path_str) else "📄"
            ctk.CTkLabel(row, text=f"{icon}  {path_str}", anchor="w").pack(
                side="left", fill="x", expand=True, padx=8, pady=6
            )
            ctk.CTkButton(
                row,
                text="✖",
                width=28,
                height=28,
                fg_color="transparent",
                hover_color=("gray80", "gray25"),
                command=lambda p=path_str: self._remove_item(p),
            ).pack(side="right", padx=6)

    def _add_files(self):
        files = filedialog.askopenfilenames(title="Chọn file để nén")
        for f in files:
            if f not in self.compress_items:
                self.compress_items.append(f)
        self._refresh_file_list_ui()

    def _add_folder(self):
        folder = filedialog.askdirectory(title="Chọn thư mục để nén")
        if folder and folder not in self.compress_items:
            self.compress_items.append(folder)
        self._refresh_file_list_ui()

    def _remove_item(self, path_str):
        self.compress_items.remove(path_str)
        self._refresh_file_list_ui()

    def _clear_compress_list(self):
        self.compress_items.clear()
        self._refresh_file_list_ui()

    def _start_compress(self):
        if self.worker and self.worker.is_alive():
            return
        if not self.compress_items:
            messagebox.showwarning(APP_NAME, "Bạn chưa thêm file hoặc thư mục nào cả! 🙈")
            return

        default_name = f"VietZIP_{datetime.now().strftime('%Y%m%d_%H%M%S')}.zip"
        output_path = filedialog.asksaveasfilename(
            title="Lưu file ZIP",
            defaultextension=".zip",
            initialfile=default_name,
            filetypes=[("ZIP archive", "*.zip")],
        )
        if not output_path:
            return

        level = COMPRESSION_LEVELS[self.level_menu.get()]
        self.compress_button.configure(state="disabled", text="⏳ Đang nén...")
        self.progress_bar.set(0)
        self._set_mascot(MASCOT_WORKING)

        self.worker = ZipWorker(
            "compress",
            {"sources": self.compress_items, "output_path": output_path, "level": level},
            self.msg_queue,
        )
        self.worker.start()

    # ---- Giải nén ----
    def _choose_zip(self):
        path = filedialog.askopenfilename(
            title="Chọn file ZIP", filetypes=[("ZIP archive", "*.zip")]
        )
        if not path:
            return
        self.zip_path_var.set(path)
        self._preview_zip_contents(path)

    def _choose_dest(self):
        folder = filedialog.askdirectory(title="Chọn thư mục để giải nén ra")
        if folder:
            self.dest_dir_var.set(folder)

    def _preview_zip_contents(self, path):
        self.zip_contents_box.configure(state="normal")
        self.zip_contents_box.delete("1.0", "end")
        try:
            with zipfile.ZipFile(path, "r") as zf:
                names = zf.namelist()
                header = f"📦 {len(names)} mục trong file ZIP:\n" + "-" * 40 + "\n"
                self.zip_contents_box.insert("end", header)
                for n in names[:500]:
                    self.zip_contents_box.insert("end", f"  {n}\n")
                if len(names) > 500:
                    self.zip_contents_box.insert(
                        "end", f"\n... và {len(names) - 500} mục khác nữa.\n"
                    )
        except zipfile.BadZipFile:
            self.zip_contents_box.insert("end", "⚠️ File này không phải ZIP hợp lệ.")
        self.zip_contents_box.configure(state="disabled")

    def _start_extract(self):
        if self.worker and self.worker.is_alive():
            return
        zip_path = self.zip_path_var.get()
        dest_dir = self.dest_dir_var.get()

        if not zip_path or not os.path.isfile(zip_path):
            messagebox.showwarning(APP_NAME, "Bạn chưa chọn file ZIP hợp lệ! 🙈")
            return
        if not dest_dir:
            messagebox.showwarning(APP_NAME, "Bạn chưa chọn nơi để giải nén! 📂")
            return

        self.extract_button.configure(state="disabled", text="⏳ Đang giải nén...")
        self.progress_bar.set(0)
        self._set_mascot(MASCOT_WORKING)

        self.worker = ZipWorker(
            "extract", {"zip_path": zip_path, "dest_dir": dest_dir}, self.msg_queue
        )
        self.worker.start()

    # ------------------------------------------------------------- Queue --
    def _poll_queue(self):
        try:
            while True:
                kind, *rest = self.msg_queue.get_nowait()

                if kind == "progress":
                    fraction, text = rest
                    self.progress_bar.set(fraction)
                    self.status_label.configure(text=text)
                    frame = int(fraction * 100) % len(MASCOT_WORKING)
                    self._set_mascot(MASCOT_WORKING, frame)

                elif kind == "compress_done":
                    info = rest[0]
                    ratio = 0
                    if info["original_size"]:
                        ratio = 100 * (1 - info["compressed_size"] / info["original_size"])
                    self.status_label.configure(
                        text=(
                            f"Xong! Đã nén {info['file_count']} mục — "
                            f"{human_size(info['original_size'])} ➜ "
                            f"{human_size(info['compressed_size'])} "
                            f"(giảm {ratio:.1f}%) 🎉"
                        )
                    )
                    self.progress_bar.set(1)
                    self._set_mascot(MASCOT_DONE)
                    self.compress_button.configure(state="normal", text="🚀 Nén ngay!")
                    messagebox.showinfo(
                        APP_NAME,
                        f"Nén thành công!\n\nFile: {info['output_path']}\n"
                        f"Số mục: {info['file_count']}\n"
                        f"Dung lượng: {human_size(info['compressed_size'])}",
                    )

                elif kind == "extract_done":
                    info = rest[0]
                    self.status_label.configure(
                        text=f"Xong! Đã giải nén {info['file_count']} mục vào {info['dest_dir']} 🎉"
                    )
                    self.progress_bar.set(1)
                    self._set_mascot(MASCOT_DONE)
                    self.extract_button.configure(state="normal", text="✨ Giải nén ngay!")
                    messagebox.showinfo(
                        APP_NAME,
                        f"Giải nén thành công vào:\n{info['dest_dir']}",
                    )

                elif kind == "error":
                    self.status_label.configure(text=f"⚠️ Lỗi: {rest[0]}")
                    self.compress_button.configure(state="normal", text="🚀 Nén ngay!")
                    self.extract_button.configure(state="normal", text="✨ Giải nén ngay!")
                    self._set_mascot(MASCOT_IDLE)
                    messagebox.showerror(APP_NAME, f"Đã có lỗi xảy ra:\n{rest[0]}")

        except queue.Empty:
            pass
        finally:
            self.after(120, self._poll_queue)


def main():
    app = VietZipApp()
    app.mainloop()


if __name__ == "__main__":
    main()
