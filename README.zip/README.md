# VietZIP 📦

Ứng dụng nén / giải nén file ZIP với giao diện hiện đại, ngộ nghĩnh, viết bằng Python.

## ✨ Tính năng

- 🗜️ **Nén file & thư mục** thành ZIP, giữ nguyên cấu trúc thư mục con
- 📂 **Giải nén** file ZIP, xem trước danh sách nội dung trước khi giải nén
- 🎚️ 4 mức độ nén: Siêu nhanh → Nén tối đa
- 📊 Thanh tiến độ theo thời gian thực + thống kê dung lượng trước/sau khi nén
- 🐼 Mascot cảm xúc thay đổi theo trạng thái (chờ / đang xử lý / hoàn thành)
- ☀️🌙 Chuyển đổi giao diện Sáng / Tối / Theo hệ thống
- ⚡ Xử lý nền bằng `threading` — giao diện không bao giờ bị đơ khi nén file lớn

## 🚀 Cài đặt & chạy

```bash
pip install -r requirements.txt
python vietzip_app.py
```

Yêu cầu Python 3.9 trở lên (đã có sẵn `tkinter`, `zipfile` trong thư viện chuẩn).

## 🖱️ Cách dùng

### Nén file
1. Vào tab **🗜️ Nén file**
2. Bấm **➕ Thêm file** hoặc **📁 Thêm thư mục** để chọn nội dung cần nén
3. Chọn **mức độ nén** phù hợp
4. Bấm **🚀 Nén ngay!** và chọn nơi lưu file `.zip`

### Giải nén
1. Vào tab **📂 Giải nén**
2. Bấm **📦 Chọn ZIP** để chọn file cần giải nén (danh sách nội dung sẽ hiện ra để xem trước)
3. Bấm **📂 Chọn thư mục** để chọn nơi giải nén ra
4. Bấm **✨ Giải nén ngay!**

## 🧱 Công nghệ sử dụng

| Thành phần        | Công nghệ                          |
|-------------------|-------------------------------------|
| Giao diện          | [CustomTkinter](https://github.com/TomSchimansky/CustomTkinter) — bo góc, dark mode, hiện đại |
| Nén / giải nén     | `zipfile` (thư viện chuẩn Python)   |
| Xử lý nền          | `threading` + `queue`               |

## 💡 Hướng phát triển thêm

- Kéo thả file trực tiếp vào cửa sổ (dùng `tkinterdnd2`)
- Đặt mật khẩu cho file ZIP
- Hỗ trợ thêm định dạng RAR / 7z (chỉ giải nén, cần thư viện ngoài)
- Đóng gói thành file `.exe` / `.app` bằng `pyinstaller`
